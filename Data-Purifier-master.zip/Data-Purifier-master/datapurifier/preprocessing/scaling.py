"""Standardisation and Normalization
"""

from sklearn.preprocessing import StandardScaler


class Scale:
    def __init__(self, df):
        pass


if __name__ == '__main__':
    pass
